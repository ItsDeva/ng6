For Angular Server 
--> Open command prompt 
--> Check Python is installed or not by running Python
--> Then put this following command on the command line
    Python 3.6 -->  python -m http.server 8000 --bind 127.0.0.1 
    Python 2.7 -->  python -m SimpleHTTPServer 8000

Open Spyder For Python Script to Run 
--> Open Server.py File in the Spyder
--> Run the File
--> Then a Flask Server is started on port 8081

Then Open Chrome Browser or any other Browser And Enter the URL
    http://localhost:8000

"466132.0","Hand Injury","71610","8","57288","Low","Processing"
