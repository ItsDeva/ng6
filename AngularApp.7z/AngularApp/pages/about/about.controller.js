crydecApp.controller('aboutController', function($scope) {
    $scope.message = 'This is a machine learning app for Insurance Fraudulant Claim Detection';
});
