# -*- coding: utf-8 -*-
"""
Created on Sun Jun 10 12:47:16 2018

@author: Karthik
"""

import pandas as pd
from sklearn import preprocessing
df=pd.read_csv("data.csv")
lab_enc = preprocessing.LabelEncoder()
#print(df.columns[-1:])
la=df.columns[-1:]
las=df[la]
#print(set(df[las.columns[0]]))
dic=set(df[las.columns[0]])
c=0
dictData={}
for i in dic:
    dictData[c]=str(i)
    c=c+1
#    print(dictData)

le=preprocessing.LabelEncoder()
##print(df[df.columns[-1:]])
#last=df[df.columns[-1:]]
#
#print(df[str(last)])

en=le.fit_transform((df[(df.columns[1])]).astype(str))
#print(list(en))
de=le.inverse_transform(en)
#print(de)
fo={}
c=len(de)
#print(len(de))
for i in range(0,c):
    fo[en[i]]=de[i]
#print(fo[1])
#
#print(df.columns[:-1].tolist())
#enattr=le.fit_transform((df[(df.columns[:-1])]))
#deattr=le.inverse_transform(enattr)
#
#print(enattr)
#print(deattr)


will=[]
for i in range(0,len(df.columns)):
#    print(i)
    will.append("will"+str(i))
#print(will)

will0={}

willlist=[]
for j in range(0,len(df.columns)):
    will0={}
    en=le.fit_transform((df[(df.columns[j])]).astype(str))
    de=le.inverse_transform(en)
    for i in range(0,len(df)):
#        print(en[i],"  ",de[i])
        will0[de[i]]=en[i]
    willlist.append(will0)
    
print("__________________________________________________________")
print(willlist[7]["Fake"])
print(willlist[0])
predictData=["4132.0","Hand Injury","71610","8.0","57288.0","Low","Processing"]
predictList=[]
for i in range(0,len(predictData)):
    if predictData[i] in willlist[i].keys():
#        print("##########################",predictData[i])
        pre=predictData[i]
        predictList.append(willlist[i][pre])
#        print("\n\n\n\n\n",willlist[i][pre])
    else:
        predictList.append(len(df))
print(predictList)    
#    print(willlist[i][str(predictData[i])])

#print(will0["Diabetics"])
