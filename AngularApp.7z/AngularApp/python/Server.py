# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 10:39:27 2018
@author: manomuth
"""
from sklearn.tree                   import DecisionTreeClassifier
from sklearn.neighbors              import KNeighborsClassifier 
from sklearn.linear_model           import LogisticRegression
from sklearn.linear_model           import SGDClassifier
#from sklearn.discriminant_analysis  import LinearDiscriminantAnalysis 
from sklearn.naive_bayes            import GaussianNB
from sklearn.svm                    import SVC
from sklearn.ensemble               import RandomForestClassifier
#from sklearn.discriminant_analysis  import QuadraticDiscriminantAnalysis
from sklearn.neural_network         import MLPClassifier
from sklearn.ensemble               import GradientBoostingClassifier
from sklearn.ensemble               import BaggingClassifier
import numpy as np
import pickle
from flask_cors import CORS
np.set_printoptions(precision=2)
import pandas as pd
from sklearn import preprocessing
from sklearn.cross_validation import train_test_split
from flask import Flask,   request,jsonify
from werkzeug import secure_filename
app = Flask(__name__)
CORS(app)
from flask import Flask 
lab_enc = preprocessing.LabelEncoder()
###############################################################################
min_max_scaler = preprocessing.MinMaxScaler(feature_range=(-1,1))
columns =[]
valuearray=[]
resultarray=[]
scorelist=[]  
score=[]
finallist=[] 
jsondic={}
valuedic={}
result_dict={}
pack={}
final={}
c=0
d=0
v=0
count=0

classifiersString=['KNeighborsClassifier','LogisticRegression','SVC'
             ,'SGDClassifier','RandomForestClassifier','GaussianNB','MLPClassifier'
             ,'BaggingClassifier','GradientBoostingClassifier','DecisionTreeClassifier']
classifiersPackage=[KNeighborsClassifier,LogisticRegression,SVC
             ,SGDClassifier,RandomForestClassifier,GaussianNB,MLPClassifier
             ,BaggingClassifier,GradientBoostingClassifier,DecisionTreeClassifier]

def filearea(filename):    
    file1 = open('config.txt','w')
    file1.write(filename)
    file1.close()
    
def fileSet():    
    filename = open('config.txt','r')
    dataset = pd.read_csv(filename.readline(),encoding = "ISO-8859-1" )
    filename.close()  
    return dataset

dataset=fileSet()
dataset2=fileSet()
encoderData=[]


le=preprocessing.LabelEncoder()

for column in dataset:
    encoderData.append(le)
    dataset[column]=le.fit_transform(dataset[column].astype(str))
#    label_encoder.inverse_transform([50]) 
print(dataset) 

def valArray():
    valuearray=[]
    dataset=fileSet()
    for value in dataset.columns[:-1]:
        valuearray.append(value)
    return (valuearray)
def resArray():
    dataset=fileSet()
    return dataset.columns[-1:]

X = dataset[valArray()]
X = np.array(X)
X = min_max_scaler.fit_transform(X)
Y = dataset[resArray()]
Y = np.array(Y)
lab_enc = preprocessing.LabelEncoder()
Y = lab_enc.fit_transform(Y)

for i in classifiersString: 
    pack[i]=classifiersPackage[v]
    v=v+1

#label_encoder.inverse_transform([50]) 

def train(classifier):
    
    classifierName=pack[classifier]
    classifierModel = classifierName()
    X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.8, random_state=5) 
    classifierModel.fit(X,Y)
    classifierModel.fit(X_train,Y_train)
    scorevalue=100* classifierModel.score(X_test,Y_test)
    score.append(round(scorevalue,2))   
    pkl_filename = classifier+"pickle_model.pkl"  
    pickle.dump(classifierModel, open(pkl_filename , 'wb'))
final={}    
def prediction(predictData,classifierModel):   
    
    re=dataset.columns[-1:] 
    li=[]
    li=set(dataset[re[0]])
    print(li)
    result_val=[]
    
    for i in li:
       count=0
       result_val.append(i)
       count=count+1
       
#    print(result_dict)
#    predictData = lab_enc.fit_transform(predictData)
    
        
    will0={}
    final.clear()
    willlist=[]
    for j in range(0,len(dataset2.columns)):
        will0={}
        en=le.fit_transform((dataset2[(dataset2.columns[j])]).astype(str))
        de=le.inverse_transform(en)
        for i in range(0,len(dataset2)):
    #        print(en[i],"  ",de[i])
            will0[de[i]]=en[i]
        willlist.append(will0)
        
    print("__________________________________________________________")
 
#    predictData=["4132.0","Hand Injury","71610","8.0","57288.0","Low","Processing"]
    predictList=[]
   
    for i in range(0,len(predictData)):
        if predictData[i] in willlist[i].keys():
    #        print("##########################",predictData[i])
            pre=predictData[i]
            predictList.append(willlist[i][pre])
    #        print("\n\n\n\n\n",willlist[i][pre])
        else:
            predictList.append(len(dataset2))
       

    print(dataset)
    print(predictList) 
    loaded_model_DT = pickle.load(open( classifierModel+"pickle_model.pkl"   , 'rb'))
    Ypredict = loaded_model_DT.predict([predictList]) 
    YpreInt=int(Ypredict)
    print(result_val[YpreInt])
    print("Index value",YpreInt)
    return YpreInt

@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file2():
  f = request.files['file']
  fileName = f.filename
  f.save(secure_filename(fileName))
  filearea(fileName)
  train('KNeighborsClassifier')       
  train('LogisticRegression')
  train('SVC')
  train('SGDClassifier')
  train('RandomForestClassifier')
  train('GaussianNB')
  train('MLPClassifier')
  train('BaggingClassifier')
  train('GradientBoostingClassifier')  
  train('DecisionTreeClassifier')
  fields={}
  c=0
  d=0
  for i in classifiersString :
    jsondic[i]=score[c]
    finallist.append(jsondic) 
    c=c+1
  valuedic={}
  valuearray=valArray()  
  for i in valuearray :
    valuedic[d]=i
    d=d+1
  print("-------------------------",valuedic)
  fields["algorithms"]=jsondic
  fields["fields"]=valuedic
  print("------fields of fields",jsonify(fields))
  return jsonify(fields)

@app.route('/predict', methods = ['GET', 'POST'])
def predict():
   d=0
   valuearray=valArray()  
   valuedic={}
   for i in valuearray :
    valuedic[i]=d
    d=d+1
   return jsonify(valuedic)

@app.route('/test', methods = ['GET', 'POST'])
def testGet():
   list1 =[]
   list2 = []
   dict1 = {}
   dict1 = request.form
   request.form['algoName']
   list1 = list(dict1)
   list1 = list1[1:]
   for i in list1:
       list2.append(dict1[i])
   return jsonify(list2)

@app.route('/victory', methods = ['GET', 'POST'])
def victory():
   if request.method == 'POST':
      list1 =[]
      list2 = []
      dict1 = {}
      dict1 = request.form
      algo=request.form['algoName']
      list1 = list(dict1)
      list1 = list1[1:]
      for i in list1:
          list2.append(dict1[i])
      clfname=algo
      predictDate=list2
      predictRes=prediction(predictDate,clfname)
      
      
      la=dataset2.columns[-1:]
      las=dataset2[la]
      print(set(dataset2[las.columns[0]]))
      dic=set(dataset2[las.columns[0]])
      c=0
      dictData={}
      for i in dic:
          dictData[c]=str(i)
          c=c+1
          print(dictData)
      
#      print(de)
#      fo={}
#      c=len(de)
#      print(len(de))
#      print(de)
#      for i in range(0,c):
#          fo[en[i]]=de[i]
#      print(predictRes)
#      print(fo[predictRes])
      
      final["final"]=dictData[predictRes]
      print(final)
      return jsonify(final)

if __name__ == '__main__':
   app.run(port=8080)